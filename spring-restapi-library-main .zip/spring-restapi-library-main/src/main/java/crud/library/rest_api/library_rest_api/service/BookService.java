package crud.library.rest_api.library_rest_api.service;

public class BookService {
}
