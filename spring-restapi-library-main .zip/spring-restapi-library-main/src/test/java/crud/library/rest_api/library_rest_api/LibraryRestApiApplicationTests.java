package crud.library.rest_api.library_rest_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
