package crud.library.rest_api.library_rest_api.model;

public class UpdateMemberRequest {



}
